import{l as o}from"./logger-T-JRt-Bg.js";o("inject loaded");
//# sourceMappingURL=inject.js.map
