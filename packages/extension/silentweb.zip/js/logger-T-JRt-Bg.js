function e(...e){console.debug("[SilentWeb]",...e)}export{e as l};
//# sourceMappingURL=logger-T-JRt-Bg.js.map
