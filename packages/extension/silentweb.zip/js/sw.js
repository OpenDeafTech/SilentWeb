self.addEventListener("install",()=>{console.debug("[SilentWeb] service worker installed")});
//# sourceMappingURL=sw.js.map
